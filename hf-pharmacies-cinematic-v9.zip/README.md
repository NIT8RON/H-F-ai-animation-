# H&F Pharmacies — Cinematic Experience

A new, independent visual version of the H&F Pharmacies website. The original site remains untouched.

## Highlights

- Cinematic pharmacy-focused hero experience
- Scroll-triggered reveal animations
- CSS 3D depth, floating cards and parallax motion
- Interactive service, branch and contact cards
- Responsive mobile animation strategy
- Existing ordering, WhatsApp, branch locator, favorites and Supabase-related functionality retained
- No GSAP, Three.js or external animation library required

## Run locally

```bash
npm install
npm run dev
```

For the original Supabase-backed functionality, copy `.env.example` to `.env` and add the environment values from the original private project.

## GitHub

Create a **new repository** for this version. Do not overwrite the original H&F Pharmacies repository until you have reviewed the new site.

## Cinematic edition
This repository is a standalone redesign of the H&F Pharmacies site. It keeps the existing ordering/WhatsApp/location flows while adding a dependency-free cinematic motion layer: scroll reveal, magnetic CTAs, 3D tilt cards, pointer aura, parallax depth, animated hero, and reduced-motion/mobile fallbacks.

Run locally with:
```bash
npm install
npm run dev
```
Build with:
```bash
npm run build
```
