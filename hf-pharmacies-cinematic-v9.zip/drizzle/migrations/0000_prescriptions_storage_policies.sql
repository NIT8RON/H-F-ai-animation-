-- Allow anyone (guest customers) to upload a prescription photo, and to create
-- signed links for the file they just uploaded. Bucket is private: files are only
-- reachable through a signed URL.
CREATE POLICY "anyone can upload prescriptions"
ON storage.objects FOR INSERT
TO anon, authenticated
WITH CHECK (bucket_id = 'prescriptions');

CREATE POLICY "anyone can read prescriptions via signed url"
ON storage.objects FOR SELECT
TO anon, authenticated
USING (bucket_id = 'prescriptions');
