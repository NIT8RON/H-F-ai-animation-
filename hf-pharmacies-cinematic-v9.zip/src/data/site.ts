export const site = {
  nameEn: "H&F Pharmacies",
  nameAr: "صيدليات هشام و فؤاد",
  phone: "01210835555",
  whatsapp: "https://wa.me/201210835555",
  instapay: "https://ipn.eg/S/hisham.hashim207001/instapay/3dMZxr",
  instagram: "https://www.instagram.com/hishamandfouad.ph",
  facebook: "https://www.facebook.com/share/19TviZWBvT/?mibextid=wwXIfr",
  review:
    "https://search.google.com/local/writereview?placeid=ChIJDVmRfSLJ9xQRTmIPfzPu61k",
  askPharmacist: "مرحبًا، أريد سؤال الصيدلي عن…",
  registerForm:
    "https://docs.google.com/forms/d/e/1FAIpQLSdhI5_TczKky4IQOnU-i3tUTVD_JRcR5yftIPI0X1z57NWu6g/viewform",
  madeBy: "https://www.instagram.com/lamsa.ea?stkn=MWRxdHY3eXppYTJ4OQ%3D%3D&utm_source=qr",
};

export const features = [
  { title: "سرعة التوصيل", sub: "لحد باب البيت", icon: "truck" as const },
  { title: "أدوية أصلية", sub: "من مصادر موثوقة", icon: "shield" as const },
  { title: "متاحين دايمًا", sub: "خدمة 24 ساعة", icon: "clock" as const },
  { title: "استشارات مجانية", sub: "فريق متخصص", icon: "heart" as const },
];

export const services = [
  {
    title: "توصيل سريع",
    desc: "طلبك يوصلك لحد باب البيت في أسرع وقت.",
    icon: "truck" as const,
  },
  {
    title: "أدوية أصلية وموثوقة",
    desc: "كل الأدوية من مصادر معتمدة ومخزنة بالطريقة الصحيحة.",
    icon: "shield" as const,
  },
  {
    title: "استشارات مجانية",
    desc: "فريق الصيدلية يجاوب على أسئلتك ويساعدك في اختيار الأنسب.",
    icon: "heart" as const,
  },
  {
    title: "سهولة في التواصل",
    desc: "اتصل أو ابعت رسالة وإحنا نكمّل معاك باقي الطلب.",
    icon: "phone" as const,
  },
];

/** مواعيد العمل: 24 ساعة، أو من ساعة لساعة (بتوقيت القاهرة، والنهاية بعد منتصف الليل تُحسب اليوم التالي) */
export type Schedule =
  | { kind: "24h" }
  | { kind: "range"; fromHour: number; toHour: number };

export type Branch = {
  name: string;
  address?: string;
  whatsapp: string;
  landlines: string[];
  hours: string;
  open24: boolean;
  schedule: Schedule;
  lat: number;
  lng: number;
  map: string;
};

const H24: Schedule = { kind: "24h" };
const NIGHT: Schedule = { kind: "range", fromHour: 9, toHour: 2 };
const HOURS_24 = "مفتوح 24 ساعة";
const HOURS_NIGHT = "من ٩ ص إلى ٢ ص";

export const branches: Branch[] = [
  {
    name: "فرع البحر",
    address: "طنطا — ش. البحر (الجيش) — عمارة الري — أمام بنك CIB",
    whatsapp: "01006665132",
    landlines: ["3400097", "3400098"],
    hours: HOURS_24,
    open24: true,
    schedule: H24,
    lat: 30.7989868,
    lng: 30.9969079,
    map: "https://goo.gl/maps/k7rzfnLRud9Vijyr5",
  },
  {
    name: "فرع بطرس",
    address:
      "طنطا — ش. بطرس من ش. سعيد — أمام مركز د. محمد مشالي (مركز طبي سعيد سابقًا)",
    whatsapp: "01006665124",
    landlines: ["3272750", "3318731", "3289797"],
    hours: HOURS_24,
    open24: true,
    schedule: H24,
    lat: 30.7935506,
    lng: 31.0021071,
    map: "https://goo.gl/maps/hEWhSsW2CR13pfPL9",
  },
  {
    name: "فرع النادي",
    address: "طنطا — ش. النادي — أمام مباحث أمن الدولة",
    whatsapp: "01026088998",
    landlines: ["3346200", "3346888"],
    hours: HOURS_24,
    open24: true,
    schedule: H24,
    lat: 30.7956834,
    lng: 30.9911021,
    map: "https://goo.gl/maps/T2z9ZtMbYGLQYyJ39",
  },
  {
    name: "فرع النادي الجديد",
    address: "ش النادي أمام بوابة نادي طنطا",
    whatsapp: "01000965768",
    landlines: ["3410691"],
    hours: HOURS_NIGHT,
    open24: false,
    schedule: NIGHT,
    lat: 30.7962,
    lng: 30.98985,
    map: "https://maps.app.goo.gl/EusAjEC3hpQ2ccPh7?g_st=ic",
  },
  {
    name: "فرع الحلو",
    whatsapp: "01006664531",
    landlines: ["3272999", "3299010"],
    hours: HOURS_NIGHT,
    open24: false,
    schedule: NIGHT,
    lat: 30.7956629,
    lng: 31.0040844,
    map: "https://goo.gl/maps/zSvTVnek7pGwqpcTA",
  },
  {
    name: "فرع الأستاذ (كنانه)",
    address: "طنطا — ش. الإستاد — أسفل عيادات كنانة",
    whatsapp: "01021993709",
    landlines: ["3576075", "3576076"],
    hours: HOURS_24,
    open24: true,
    schedule: H24,
    lat: 30.8162785,
    lng: 30.992607,
    map: "https://goo.gl/maps/6aY7bddTBLhw84Pw6",
  },
  {
    name: "فرع حسن رضوان",
    address: "طنطا — ش. حسن رضوان مع ش. مصطفى كامل",
    whatsapp: "01006664509",
    landlines: ["3323058", "3293434"],
    hours: HOURS_NIGHT,
    open24: false,
    schedule: NIGHT,
    lat: 30.7921972,
    lng: 31.0093728,
    map: "https://goo.gl/maps/iUhRYjMfzYhtcU8P8",
  },
];

/** منتجات وطلبات شائعة — تقدر تضيفها للمفضلة وتطلبها بسرعة */
export const quickItems = [
  "مسكن للصداع",
  "خافض حرارة",
  "أدوية برد وإنفلونزا",
  "فيتامين C",
  "فيتامين D",
  "مكملات حديد",
  "شراب كحة",
  "أدوية معدة وحرقان",
  "مضاد حيوي بالروشتة",
  "جهاز قياس ضغط",
  "شرائط سكر",
  "كمامات ومطهرات",
  "مستلزمات جروح",
  "منتجات عناية بالبشرة",
  "لبن أطفال",
  "حفاضات أطفال",
];

export const aboutPoints = [
  "أدوية أصلية من مصادر موثوقة",
  "توصيل سريع لحد باب البيت",
  "استشارات مجانية من فريق الصيدلية",
  "اهتمام حقيقي بكل عميل وسهولة في التواصل",
];

export const trustBar = [
  { title: "موثوق", sub: "من 1999" },
  { title: "توصيل", sub: "سريع وسهل" },
  { title: "دعم", sub: "في أي وقت" },
  { title: "اهتمام", sub: "بكل عميل" },
];

export const navLinks = [
  { label: "الرئيسية", href: "#home" },
  { label: "خدماتنا", href: "#services" },
  { label: "فروعنا", href: "#branches" },
  { label: "من نحن", href: "#about" },
  { label: "تواصل معنا", href: "#contact" },
];

/** فرع شارع البحر — رقم الواتساب المستخدم في "اسأل صيدلي" ورفع الروشتة */
export const bahrBranch: Branch =
  branches.find((b) => b.name === "فرع البحر") ?? branches[0]!;

export const waLink = (localNumber: string, text?: string) =>
  `https://wa.me/2${localNumber.replace(/^0+/, "0").replace(/\D/g, "")}${
    text ? `?text=${encodeURIComponent(text)}` : ""
  }`;

export const askPharmacistLink = waLink(bahrBranch.whatsapp, site.askPharmacist);
