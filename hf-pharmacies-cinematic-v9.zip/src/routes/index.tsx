import { createFileRoute } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { OrderProvider } from "@/components/site/OrderDialog";
import { QuickActions } from "@/components/site/QuickActions";
import { NearestBranch } from "@/components/site/NearestBranch";
import { Favorites } from "@/components/site/Favorites";
import { InstallHint } from "@/components/site/InstallHint";
import { MotionSystem } from "@/components/site/MotionSystem";
import { About, Branches, Contact, Footer, Hero, Services, SocialHub } from "@/components/site/Sections";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "صيدليات هشام و فؤاد | تجربة صيدلية حديثة" },
    { name: "description", content: "صيدليات هشام و فؤاد في طنطا منذ 1999 — أدوية أصلية، توصيل سريع، واستشارات مجانية." },
    { property: "og:title", content: "صيدليات هشام و فؤاد" },
    { property: "og:description", content: "أدوية أصلية، توصيل سريع، واستشارات مجانية." },
    { property: "og:type", content: "website" },
  ]}),
  component: Index,
});

function Index() {
  return <OrderProvider><div dir="rtl" lang="ar" className="site-shell"><MotionSystem/><Header/><main><Hero/><QuickActions/><Services/><NearestBranch/><Branches/><Favorites/><SocialHub/><About/><Contact/></main><InstallHint/><Footer/></div></OrderProvider>;
}
