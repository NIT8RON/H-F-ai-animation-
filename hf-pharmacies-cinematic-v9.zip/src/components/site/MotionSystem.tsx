import { useEffect } from "react";

/**
 * Lightweight cinematic interaction layer.
 *
 * Deliberately dependency-free so the site keeps its motion system even when
 * the package registry is unavailable. It handles:
 * - viewport reveals (including elements added after mount)
 * - cursor aura / global pointer tracking
 * - card tilt and magnetic controls
 * - scroll progress + velocity for CSS-driven atmosphere
 * - prefers-reduced-motion without leaving hidden content behind
 */
export function MotionSystem() {
  useEffect(() => {
    const root = document.documentElement;
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");

    let raf = 0;
    let scrollRaf = 0;
    let revealObserver: IntersectionObserver | null = null;
    let mutationObserver: MutationObserver | null = null;
    let mutationRaf = 0;
    let lastScrollY = window.scrollY;
    let lastScrollTime = performance.now();

    const setReducedMotionState = () => {
      document.body.classList.toggle("motion-reduced", reducedMotion.matches);
    };

    const bindReveals = () => {
      if (!revealObserver) return;
      document
        .querySelectorAll<HTMLElement>(".reveal:not(.motion-bound)")
        .forEach((element) => {
          element.classList.add("motion-bound");
          revealObserver?.observe(element);
        });
    };

    const revealAll = () => {
      document.querySelectorAll<HTMLElement>(".reveal").forEach((element) => {
        element.classList.add("is-visible", "motion-bound");
      });
    };

    setReducedMotionState();

    if (reducedMotion.matches) revealAll();

    let mx = innerWidth / 2;
    let my = innerHeight / 2;
    let pointerTicking = false;

    const paintPointer = () => {
      pointerTicking = false;
      root.style.setProperty("--cursor-x", `${mx}px`);
      root.style.setProperty("--cursor-y", `${my}px`);
      root.style.setProperty("--pointer-active", "1");
    };

    const onPointer = (event: PointerEvent) => {
      if (event.pointerType === "touch") return;
      mx = event.clientX;
      my = event.clientY;
      if (!pointerTicking) {
        pointerTicking = true;
        raf = requestAnimationFrame(paintPointer);
      }
    };

    revealObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          const element = entry.target as HTMLElement;
          element.classList.add("is-visible");
          revealObserver?.unobserve(element);
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px -8% 0px" },
    );
    bindReveals();

    // Components are currently static, but this keeps the motion system safe
    // if a dialog/list/section is rendered later by React.
    mutationObserver = new MutationObserver(() => {
      if (mutationRaf) return;
      mutationRaf = requestAnimationFrame(() => {
        mutationRaf = 0;
        bindReveals();
        bindInteractiveMotion();
      });
    });
    mutationObserver.observe(document.body, { childList: true, subtree: true });

    const cleanups: Array<() => void> = [];
    const boundTilt = new WeakSet<HTMLElement>();
    const boundMagnetic = new WeakSet<HTMLElement>();

    const bindTiltCards = () => {
      document.querySelectorAll<HTMLElement>(".tilt-card").forEach((card) => {
        if (boundTilt.has(card)) return;
        boundTilt.add(card);
        const onMove = (event: PointerEvent) => {
          if (event.pointerType === "touch") return;
          const rect = card.getBoundingClientRect();
          if (!rect.width || !rect.height) return;
          const x = (event.clientX - rect.left) / rect.width - 0.5;
          const y = (event.clientY - rect.top) / rect.height - 0.5;
          card.style.setProperty("--card-x", `${(x + 0.5) * 100}%`);
          card.style.setProperty("--card-y", `${(y + 0.5) * 100}%`);
          card.style.setProperty("--rx", `${-y * 7}deg`);
          card.style.setProperty("--ry", `${x * 9}deg`);
          card.style.setProperty("--px", `${x * 8}px`);
          card.style.setProperty("--py", `${y * 8}px`);
          card.classList.add("is-tilting");
        };
        const reset = () => {
          card.style.setProperty("--rx", "0deg");
          card.style.setProperty("--ry", "0deg");
          card.style.setProperty("--px", "0px");
          card.style.setProperty("--py", "0px");
          card.classList.remove("is-tilting");
        };
        card.addEventListener("pointermove", onMove, { passive: true });
        card.addEventListener("pointerleave", reset, { passive: true });
        cleanups.push(() => {
          card.removeEventListener("pointermove", onMove);
          card.removeEventListener("pointerleave", reset);
        });
      });
    };

    const bindMagnetic = () => {
      document.querySelectorAll<HTMLElement>(".magnetic").forEach((button) => {
        if (boundMagnetic.has(button)) return;
        boundMagnetic.add(button);
        const onMove = (event: PointerEvent) => {
          if (event.pointerType === "touch") return;
          const rect = button.getBoundingClientRect();
          if (!rect.width || !rect.height) return;
          const x = (event.clientX - rect.left) / rect.width - 0.5;
          const y = (event.clientY - rect.top) / rect.height - 0.5;
          button.style.setProperty("--mx-btn", `${x * 10}px`);
          button.style.setProperty("--my-btn", `${y * 7}px`);
        };
        const reset = () => {
          button.style.setProperty("--mx-btn", "0px");
          button.style.setProperty("--my-btn", "0px");
        };
        button.addEventListener("pointermove", onMove, { passive: true });
        button.addEventListener("pointerleave", reset, { passive: true });
        cleanups.push(() => {
          button.removeEventListener("pointermove", onMove);
          button.removeEventListener("pointerleave", reset);
        });
      });
    };

    const bindInteractiveMotion = () => {
      bindTiltCards();
      bindMagnetic();
    };

    bindInteractiveMotion();

    const paintScroll = () => {
      scrollRaf = 0;
      const now = performance.now();
      const scrollTop = window.scrollY;
      const max = Math.max(1, document.documentElement.scrollHeight - innerHeight);
      const dt = Math.max(16, now - lastScrollTime);
      const velocity = Math.max(-2, Math.min(2, (scrollTop - lastScrollY) / dt));

      root.style.setProperty("--scroll-progress", `${Math.min(1, scrollTop / max)}`);
      root.style.setProperty("--scroll-velocity", velocity.toFixed(3));
      root.style.setProperty("--scroll-y", `${scrollTop}px`);
      const hero = document.querySelector<HTMLElement>(".hero-scene-v2");
      if (hero) {
        const rect = hero.getBoundingClientRect();
        const progress = Math.max(0, Math.min(1, -rect.top / Math.max(1, rect.height)));
        root.style.setProperty("--hero-scroll-progress", progress.toFixed(3));
        root.style.setProperty("--hero-scroll-y", `${progress * -34}px`);
        root.style.setProperty("--hero-scroll-x", `${progress * 10}px`);
        root.style.setProperty("--hero-panel-scale", `${1 - progress * 0.035}`);
      }
      document.body.classList.toggle("is-scrolling", scrollTop > 20);

      // Section-aware parallax for the floating medical objects. Each object
      // gets a different depth so the background feels like a real layered
      // scene rather than a single looping animation.
      document.querySelectorAll<HTMLElement>(".motion-object").forEach((object) => {
        const rect = object.getBoundingClientRect();
        const depth = Number(object.style.getPropertyValue("--object-depth")) || 1;
        const distance = ((innerHeight * 0.5 - (rect.top + rect.height * 0.5)) / Math.max(innerHeight, 1));
        object.style.setProperty("--object-parallax", `${distance * depth * 70}px`);
      });

      lastScrollY = scrollTop;
      lastScrollTime = now;
    };

    const onScroll = () => {
      if (!scrollRaf) scrollRaf = requestAnimationFrame(paintScroll);
    };

    const onReducedMotionChange = () => {
      setReducedMotionState();
      if (reducedMotion.matches) revealAll();
    };

    reducedMotion.addEventListener("change", onReducedMotionChange);
    window.addEventListener("pointermove", onPointer, { passive: true });
    window.addEventListener("scroll", onScroll, { passive: true });
    paintScroll();
    paintPointer();

    return () => {
      cancelAnimationFrame(raf);
      cancelAnimationFrame(scrollRaf);
      cancelAnimationFrame(mutationRaf);
      reducedMotion.removeEventListener("change", onReducedMotionChange);
      window.removeEventListener("pointermove", onPointer);
      window.removeEventListener("scroll", onScroll);
      revealObserver?.disconnect();
      mutationObserver?.disconnect();
      cleanups.forEach((cleanup) => cleanup());
    };
  }, []);

  return <><div className="cursor-aura" aria-hidden="true" /><div className="cinematic-progress" aria-hidden="true" /></>;
}
