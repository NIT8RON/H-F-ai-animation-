import { Heart, ShoppingCart, Trash2 } from "lucide-react";
import { quickItems } from "@/data/site";
import { useFavorites } from "@/lib/store";
import { useOrder } from "./OrderDialog";

export function Favorites() {
  const { favorites, toggle, clear } = useFavorites();
  const { openOrder } = useOrder();

  return (
    <section id="favorites" className="py-16">
      <div className="mx-auto max-w-4xl px-4 sm:px-6">
        <div className="mx-auto mb-8 max-w-2xl text-center">
          <span className="eyebrow">المفضلة</span>
          <h2 className="mt-3 text-3xl font-extrabold">❤️ المفضلة</h2>
          <p className="mt-3 text-muted-foreground">
            اضغط على القلب لإضافة المنتج للمفضلة، وابعت طلبك بضغطة واحدة.
          </p>
        </div>

        {favorites.length > 0 && (
          <div className="glass-card mb-6 rounded-3xl p-5">
            <div className="flex flex-wrap gap-2">
              {favorites.map((f) => (
                <span
                  key={f}
                  className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1.5 text-xs font-bold text-primary ring-1 ring-primary/30"
                >
                  {f}
                </span>
              ))}
            </div>
            <div className="mt-4 flex flex-col gap-2 sm:flex-row">
              <button
                type="button"
                onClick={() => openOrder({ items: favorites.join("\n") })}
                className="btn-red inline-flex flex-1 items-center justify-center gap-2 rounded-full px-4 py-2.5 text-sm font-bold"
              >
                <ShoppingCart className="size-4" />
                اطلب المفضلة ({favorites.length})
              </button>
              <button
                type="button"
                onClick={clear}
                className="inline-flex items-center justify-center gap-2 rounded-full border border-border px-4 py-2.5 text-sm font-bold"
              >
                <Trash2 className="size-4 text-primary" />
                تفريغ المفضلة
              </button>
            </div>
          </div>
        )}

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {quickItems.map((item) => {
            const active = favorites.includes(item);
            return (
              <div
                key={item}
                className="glass-card flex items-center justify-between gap-2 rounded-2xl p-4"
              >
                <span className="text-sm font-semibold">{item}</span>
                <div className="flex shrink-0 items-center gap-1">
                  <button
                    type="button"
                    aria-label={active ? `إزالة ${item} من المفضلة` : `إضافة ${item} للمفضلة`}
                    aria-pressed={active}
                    onClick={() => toggle(item)}
                    className="inline-flex size-9 items-center justify-center rounded-full border border-border"
                  >
                    <Heart
                      className={`size-4 ${active ? "fill-primary text-primary" : "text-muted-foreground"}`}
                    />
                  </button>
                  <button
                    type="button"
                    aria-label={`اطلب ${item}`}
                    onClick={() => openOrder({ addItem: item })}
                    className="inline-flex size-9 items-center justify-center rounded-full border border-border"
                  >
                    <ShoppingCart className="size-4 text-primary" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
