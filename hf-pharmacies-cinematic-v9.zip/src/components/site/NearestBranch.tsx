import { useCallback, useEffect, useState } from "react";
import { Clock, MapPin, MessageCircle, Navigation, Phone } from "lucide-react";
import { branches, type Branch } from "@/data/site";
import { formatDistance, isOpenNow, rankBranches } from "@/lib/hours";
import { useOrder } from "./OrderDialog";
import { useNow } from "@/lib/use-now";

export function NearestBranch() {
  const { openOrder } = useOrder();
  const now = useNow();
  const [status, setStatus] = useState<"idle" | "loading" | "ok" | "error">("idle");
  const [result, setResult] = useState<{ branch: Branch; km: number } | null>(null);
  const [showAll, setShowAll] = useState(false);

  const locate = useCallback(() => {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      setStatus("error");
      return;
    }
    setStatus("loading");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const ranked = rankBranches(
          { lat: pos.coords.latitude, lng: pos.coords.longitude },
          branches,
        );
        setResult(ranked[0] ?? null);
        setStatus(ranked[0] ? "ok" : "error");
      },
      () => {
        setResult(null);
        setStatus("error");
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 },
    );
  }, []);

  useEffect(() => {
    const handler = () => locate();
    window.addEventListener("hf-locate", handler);
    return () => window.removeEventListener("hf-locate", handler);
  }, [locate]);

  const open = result ? isOpenNow(result.branch.schedule, now) : false;

  return (
    <section id="nearest" className="py-16">
      <div className="mx-auto max-w-2xl px-4 sm:px-6">
        <div className="glass-card rounded-3xl p-6 text-center sm:p-8">
          <span className="eyebrow">أقرب فرع</span>
          <h2 className="mt-3 text-2xl font-extrabold">اعرف أقرب فرع ليك</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            بنستخدم موقعك الفعلي لحساب المسافة لكل فروعنا ونختار الأقرب.
          </p>

          <button
            type="button"
            onClick={locate}
            disabled={status === "loading"}
            className="btn-red mt-5 inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-bold disabled:opacity-60"
          >
            <Navigation className={`size-5 ${status === "loading" ? "animate-pulse" : ""}`} />
            {status === "loading" ? "جاري تحديد موقعك..." : "حدّد موقعي"}
          </button>

          {status === "error" && (
            <div className="mt-5 space-y-3">
              <p className="text-sm font-bold text-primary">لم نتمكن من تحديد موقعك</p>
              <button
                type="button"
                onClick={() => {
                  setShowAll(true);
                  document
                    .getElementById("branches")
                    ?.scrollIntoView({ behavior: "smooth", block: "start" });
                }}
                className="inline-flex items-center gap-2 rounded-full border border-border px-5 py-2.5 text-sm font-bold"
              >
                <MapPin className="size-4 text-primary" />
                عرض جميع الفروع
              </button>
              {showAll && (
                <p className="text-xs text-muted-foreground">كل الفروع موجودة في قسم «فروعنا».</p>
              )}
            </div>
          )}

          {status === "ok" && result && (
            <div className="mt-6 rounded-3xl border border-border bg-surface p-5 text-right">
              <p className="text-sm font-bold">
                أقرب فرع ليك هو:{" "}
                <span className="text-primary">{result.branch.name}</span>
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                المسافة التقريبية: {formatDistance(result.km)}
              </p>
              {result.branch.address && (
                <p className="mt-2 text-sm text-muted-foreground">{result.branch.address}</p>
              )}
              <p className="mt-3 flex items-center gap-2 text-xs">
                <Clock className="size-3.5 text-primary" />
                {result.branch.hours}
                <span className="font-bold">{open ? "🟢 مفتوح الآن" : "🔴 مغلق الآن"}</span>
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <a
                  href={`tel:${result.branch.whatsapp}`}
                  className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-1.5 text-xs font-semibold"
                >
                  <Phone className="size-3.5 text-primary" />
                  {result.branch.whatsapp}
                </a>
                {result.branch.landlines.map((n) => (
                  <a
                    key={n}
                    href={`tel:0${n}`}
                    className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-1.5 text-xs font-semibold"
                  >
                    <Phone className="size-3.5 text-primary" />
                    {n}
                  </a>
                ))}
              </div>
              <div className="mt-4 flex flex-col gap-2 sm:flex-row">
                <button
                  type="button"
                  onClick={() => openOrder({ branch: result.branch.name })}
                  className="btn-red inline-flex flex-1 items-center justify-center gap-2 rounded-full px-4 py-2.5 text-sm font-bold"
                >
                  <MessageCircle className="size-4" />
                  اطلب من هذا الفرع
                </button>
                <a
                  href={result.branch.map}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center justify-center gap-2 rounded-full border border-border px-4 py-2.5 text-sm font-bold"
                >
                  <MapPin className="size-4 text-primary" />
                  🗺️ افتح على Google Maps
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
