import type { CSSProperties, ReactNode } from "react";

type Scene = "services" | "branches" | "social" | "about" | "contact";
type Kind =
  | "capsule" | "tablet" | "bottle" | "plus" | "molecule" | "heartbeat" | "ring" | "spark" | "cross"
  | "serum" | "cream" | "sunscreen" | "dropper" | "shampoo" | "skincare" | "box" | "droplet";

type Item = {
  kind: Kind; x: string; y: string; size?: number; rotate?: number; delay?: number; duration?: number; depth?: number;
  tone?: "red" | "white" | "soft" | "skin";
};

const scenes: Record<Scene, Item[]> = {
  services: [
    { kind: "capsule", x: "5%", y: "13%", size: 86, rotate: -24, delay: -1, duration: 9, depth: 1.5 },
    { kind: "serum", x: "88%", y: "15%", size: 112, rotate: 9, delay: -4, duration: 11, depth: 1.8, tone: "skin" },
    { kind: "tablet", x: "83%", y: "42%", size: 34, rotate: 28, delay: -4, duration: 7, depth: 2, tone: "white" },
    { kind: "sunscreen", x: "12%", y: "67%", size: 106, rotate: -8, delay: -3, duration: 13, depth: 1.1, tone: "skin" },
    { kind: "molecule", x: "18%", y: "82%", size: 76, delay: -3, duration: 13, depth: 1.1, tone: "soft" },
    { kind: "plus", x: "94%", y: "73%", size: 68, rotate: 12, delay: -6, duration: 10, depth: 1.5 },
    { kind: "ring", x: "51%", y: "32%", size: 190, delay: -8, duration: 18, depth: .7, tone: "soft" },
    { kind: "spark", x: "70%", y: "84%", size: 38, rotate: 20, delay: -2, duration: 6, depth: 1.7 },
  ],
  branches: [
    { kind: "bottle", x: "4%", y: "18%", size: 88, rotate: -7, delay: -5, duration: 12, depth: 1.4 },
    { kind: "cream", x: "86%", y: "18%", size: 118, rotate: 8, delay: -2, duration: 12, depth: 1.6, tone: "skin" },
    { kind: "capsule", x: "92%", y: "45%", size: 72, rotate: 35, delay: -1, duration: 8, depth: 1.8, tone: "white" },
    { kind: "dropper", x: "13%", y: "76%", size: 106, rotate: -12, delay: -7, duration: 13, depth: 1.3, tone: "skin" },
    { kind: "molecule", x: "84%", y: "78%", size: 92, delay: -9, duration: 15, depth: .9, tone: "soft" },
    { kind: "tablet", x: "48%", y: "14%", size: 22, rotate: 55, delay: -3, duration: 6, depth: 2 },
    { kind: "ring", x: "52%", y: "82%", size: 140, delay: -8, duration: 16, depth: .6, tone: "soft" },
  ],
  social: [
    { kind: "ring", x: "10%", y: "30%", size: 150, delay: -3, duration: 16, depth: .8, tone: "soft" },
    { kind: "spark", x: "87%", y: "22%", size: 44, rotate: 15, delay: -1, duration: 7, depth: 1.8 },
    { kind: "serum", x: "78%", y: "70%", size: 105, rotate: 17, delay: -5, duration: 11, depth: 1.4, tone: "skin" },
    { kind: "sunscreen", x: "7%", y: "74%", size: 100, rotate: -14, delay: -4, duration: 12, depth: 1.5, tone: "skin" },
    { kind: "plus", x: "18%", y: "55%", size: 54, rotate: 18, delay: -4, duration: 8, depth: 1.7, tone: "white" },
    { kind: "droplet", x: "56%", y: "16%", size: 56, rotate: 12, delay: -6, duration: 8, depth: 1.2, tone: "skin" },
  ],
  about: [
    { kind: "bottle", x: "92%", y: "14%", size: 88, rotate: 9, delay: -4, duration: 13, depth: 1.1 },
    { kind: "serum", x: "6%", y: "28%", size: 108, rotate: -16, delay: -8, duration: 10, depth: 1.6, tone: "skin" },
    { kind: "capsule", x: "7%", y: "66%", size: 78, rotate: 42, delay: -8, duration: 9, depth: 1.5 },
    { kind: "heartbeat", x: "81%", y: "66%", size: 125, delay: -2, duration: 8, depth: 1.2, tone: "soft" },
    { kind: "molecule", x: "14%", y: "86%", size: 84, delay: -10, duration: 14, depth: .8, tone: "white" },
    { kind: "skincare", x: "74%", y: "86%", size: 115, rotate: 5, delay: -4, duration: 12, depth: 1.3, tone: "skin" },
    { kind: "plus", x: "53%", y: "13%", size: 44, rotate: 8, delay: -5, duration: 7, depth: 1.9 },
  ],
  contact: [
    { kind: "capsule", x: "8%", y: "18%", size: 72, rotate: -30, delay: -2, duration: 9, depth: 1.7 },
    { kind: "shampoo", x: "88%", y: "18%", size: 120, rotate: 7, delay: -6, duration: 12, depth: 1.2, tone: "skin" },
    { kind: "cream", x: "10%", y: "70%", size: 112, rotate: -12, delay: -4, duration: 12, depth: 1.3, tone: "skin" },
    { kind: "cross", x: "15%", y: "84%", size: 64, rotate: -12, delay: -3, duration: 10, depth: 1.3, tone: "soft" },
    { kind: "ring", x: "83%", y: "78%", size: 160, delay: -9, duration: 17, depth: .8, tone: "soft" },
    { kind: "spark", x: "55%", y: "22%", size: 35, rotate: 30, delay: -4, duration: 6, depth: 1.9 },
    { kind: "droplet", x: "58%", y: "84%", size: 48, rotate: 8, delay: -1, duration: 8, depth: 1.5, tone: "skin" },
  ],
};

function Shape({ kind }: { kind: Kind }): ReactNode {
  switch (kind) {
    case "capsule": return <span className="medical-shape capsule"><i /><b /></span>;
    case "tablet": return <span className="medical-shape tablet"><i /></span>;
    case "bottle": return <span className="medical-shape bottle"><i /><b /><em /></span>;
    case "serum": return <span className="medical-shape serum"><i /><b /><em /></span>;
    case "cream": return <span className="medical-shape cream"><i /><b /></span>;
    case "sunscreen": return <span className="medical-shape sunscreen"><i /><b /><em /></span>;
    case "dropper": return <span className="medical-shape dropper"><i /><b /><em /></span>;
    case "shampoo": return <span className="medical-shape shampoo"><i /><b /><em /></span>;
    case "skincare": return <span className="medical-shape skincare"><i /><b /></span>;
    case "box": return <span className="medical-shape box"><i /><b /></span>;
    case "droplet": return <span className="medical-shape droplet" />;
    case "plus": return <span className="medical-shape plus"><i /><b /></span>;
    case "cross": return <span className="medical-shape cross"><i /><b /></span>;
    case "molecule": return <span className="medical-shape molecule"><i /><b /><em /><u /></span>;
    case "heartbeat": return <span className="medical-shape heartbeat"><svg viewBox="0 0 160 60" aria-hidden="true"><path d="M4 31h32l10-22 14 42 14-32 10 12h72" /></svg></span>;
    case "ring": return <span className="medical-shape ring" />;
    default: return <span className="medical-shape spark"><i /><b /></span>;
  }
}

export function CinematicBackground({ scene }: { scene: Scene }) {
  return (
    <div className={`cinematic-bg cinematic-bg-${scene}`} aria-hidden="true">
      <div className="cinematic-bg-glow" />
      <div className="cinematic-bg-grid" />
      <div className="cinematic-bg-noise" />
      {scenes[scene].map((item, index) => (
        <span
          className={`motion-object motion-${item.kind} tone-${item.tone ?? "red"}`}
          key={`${scene}-${item.kind}-${index}`}
          style={{
            left: item.x,
            top: item.y,
            width: item.size,
            height: item.size,
            "--object-depth": item.depth ?? 1,
            "--object-rotate": `${item.rotate ?? 0}deg`,
            "--object-delay": `${item.delay ?? 0}s`,
            "--object-duration": `${item.duration ?? 10}s`,
          } as CSSProperties}
        >
          <Shape kind={item.kind} />
        </span>
      ))}
    </div>
  );
}
