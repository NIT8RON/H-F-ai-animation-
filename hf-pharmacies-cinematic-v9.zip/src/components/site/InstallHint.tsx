import { useEffect, useState } from "react";
import { Share2, X } from "lucide-react";

const KEY = "hf_ios_install_hint_v1";

export function InstallHint() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    try {
      if (localStorage.getItem(KEY)) return;
    } catch {
      return;
    }
    const ua = window.navigator.userAgent;
    const isIOS = /iPad|iPhone|iPod/.test(ua);
    const standalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    if (isIOS && !standalone) setShow(true);
  }, []);

  const dismiss = () => {
    try {
      localStorage.setItem(KEY, "1");
    } catch {
      /* ignore */
    }
    setShow(false);
  };

  if (!show) return null;

  return (
    <div className="fixed inset-x-3 bottom-3 z-50 flex items-center gap-3 rounded-2xl border border-border bg-background/95 p-3 text-right shadow-xl backdrop-blur">
      <Share2 className="size-5 shrink-0 text-primary" />
      <p className="flex-1 text-xs leading-relaxed">
        لتثبيت التطبيق: اضغط مشاركة ثم «إضافة إلى الشاشة الرئيسية»
      </p>
      <button
        type="button"
        aria-label="إغلاق"
        onClick={dismiss}
        className="inline-flex size-8 shrink-0 items-center justify-center rounded-full border border-border"
      >
        <X className="size-4" />
      </button>
    </div>
  );
}
