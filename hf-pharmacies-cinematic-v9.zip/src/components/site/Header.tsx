import { useEffect, useState } from "react";
import { Menu, MessageCircle, Phone, X } from "lucide-react";
import { site, navLinks } from "@/data/site";
import { OrderDialog } from "./OrderDialog";
import { useLastOrder } from "@/lib/store";

export function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const lastOrder = useLastOrder();
  useEffect(() => { const f=()=>setScrolled(window.scrollY>30); window.addEventListener('scroll',f,{passive:true}); return()=>window.removeEventListener('scroll',f); },[]);
  const go=(href:string)=>{ setOpen(false); document.querySelector(href)?.scrollIntoView({behavior:'smooth'}); };
  return <header className={`site-header ${scrolled?'is-scrolled':''} ${open?'menu-open':''}`}>
    <div className="mx-auto flex h-[74px] max-w-7xl items-center justify-between gap-4 px-5 sm:px-8">
      <button type="button" onClick={()=>go('#home')} className="brand" aria-label="العودة للرئيسية">
        <img src="/hf-logo.jpeg" alt="H&F" width="44" height="44" decoding="async" />
        <span><b>{site.nameAr}</b><small>H&amp;F PHARMACIES</small></span>
      </button>
      <nav className="hidden lg:flex items-center gap-7" aria-label="التنقل الرئيسي">{navLinks.map(l=><button key={l.href} onClick={()=>go(l.href)}>{l.label}</button>)}</nav>
      <div className="hidden md:flex items-center gap-2"><a className="header-phone" href={`tel:${site.phone}`}><Phone/> {site.phone}</a><OrderDialog className="btn-red inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold"><MessageCircle/> اطلب أوردر</OrderDialog></div>
      <button type="button" className="menu-btn lg:hidden" onClick={()=>setOpen(v=>!v)} aria-label={open?'إغلاق القائمة':'فتح القائمة'} aria-expanded={open} aria-controls="mobile-navigation">{open?<X/>:<Menu/>}</button>
    </div>
    <div id="mobile-navigation" className={`mobile-nav ${open?'is-open':''}`} aria-hidden={!open}>
      <div className="mobile-nav-links">{navLinks.map(l=><button key={l.href} onClick={()=>go(l.href)}>{l.label}</button>)}</div>
      <a href={`tel:${site.phone}`}><Phone/> {site.phone}</a>
      <OrderDialog className="btn-red inline-flex w-full items-center justify-center gap-2 rounded-full px-4 py-3 font-bold"><MessageCircle/> اطلب أوردر</OrderDialog>
      {lastOrder&&<span className="text-xs text-muted-foreground">آخر طلب محفوظ على جهازك</span>}
    </div>
  </header>;
}
