import { Camera, MapPin, RotateCcw, ShoppingCart, Stethoscope } from "lucide-react";
import { askPharmacistLink } from "@/data/site";
import { useLastOrder } from "@/lib/store";
import { useOrder } from "./OrderDialog";

export function QuickActions() {
  const { openOrder } = useOrder();
  const lastOrder = useLastOrder();

  const scrollToNearest = () => {
    document.getElementById("nearest")?.scrollIntoView({ behavior: "smooth", block: "start" });
    window.dispatchEvent(new Event("hf-locate"));
  };

  return (
    <section id="quick" className="pt-2 pb-10">
      <div className="mx-auto max-w-2xl px-0 sm:px-6">
        <div className="grid gap-3 sm:grid-cols-3">
          <button
            type="button"
            onClick={() => openOrder()}
            className="btn-red flex min-h-24 flex-col items-center justify-center gap-2 rounded-3xl px-4 py-5 text-sm font-extrabold"
          >
            <ShoppingCart className="size-6" />
            🛒 اطلب الآن
          </button>
          <button
            type="button"
            onClick={() => openOrder({ photo: true })}
            className="glass-card flex min-h-24 flex-col items-center justify-center gap-2 rounded-3xl px-4 py-5 text-sm font-extrabold transition-transform hover:-translate-y-0.5"
          >
            <Camera className="size-6 text-primary" />
            📷 ارفع صورة روشتتك
          </button>
          <button
            type="button"
            onClick={scrollToNearest}
            className="glass-card flex min-h-24 flex-col items-center justify-center gap-2 rounded-3xl px-4 py-5 text-sm font-extrabold transition-transform hover:-translate-y-0.5"
          >
            <MapPin className="size-6 text-primary" />
            📍 اعرف أقرب فرع ليك
          </button>
        </div>

        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <a
            href={askPharmacistLink}
            target="_blank"
            rel="noreferrer"
            id="ask"
            className="inline-flex items-center justify-center gap-2 rounded-full border border-border bg-surface px-5 py-3 text-sm font-bold transition-colors hover:border-primary/60"
          >
            <Stethoscope className="size-5 text-primary" />
            🧑‍⚕️ اسأل الصيدلي
          </a>
          {lastOrder && (
            <button
              type="button"
              onClick={() => openOrder({ restoreLast: true })}
              className="inline-flex items-center justify-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-5 py-3 text-sm font-bold text-primary"
            >
              <RotateCcw className="size-5" />
              🔄 إعادة طلب آخر أوردر
            </button>
          )}
        </div>
      </div>
    </section>
  );
}
