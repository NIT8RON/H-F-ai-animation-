import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  Camera,
  ImagePlus,
  MapPin,
  MessageCircle,
  Navigation,
  RotateCcw,
  Trash2,
  X,
} from "lucide-react";
import { z } from "zod";
import { bahrBranch, branches, site } from "@/data/site";
import { compressPrescription, uploadPrescription } from "@/lib/prescription";
import { saveLastOrder, useLastOrder, type SavedOrder } from "@/lib/store";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export type OrderPrefill = {
  branch?: string;
  items?: string;
  addItem?: string;
  photo?: boolean;
  restoreLast?: boolean;
};

type OrderCtx = { openOrder: (prefill?: OrderPrefill) => void };

const Ctx = createContext<OrderCtx>({ openOrder: () => {} });

export function useOrder() {
  return useContext(Ctx);
}

const orderSchema = z.object({
  name: z.string().trim().nonempty({ message: "اكتب اسمك" }).max(80),
  phone: z
    .string()
    .trim()
    .regex(/^0?1[0-9]{9}$/, { message: "اكتب رقم موبايل صحيح (11 رقم)" }),
  branch: z.string().trim().nonempty({ message: "اختار الفرع" }),
  items: z.string().trim().max(800),
  address: z.string().trim().nonempty({ message: "اكتب العنوان" }).max(200),
  floor: z.string().trim().nonempty({ message: "اكتب الدور" }).max(30),
  apartment: z.string().trim().nonempty({ message: "اكتب رقم الشقة" }).max(30),
  landmark: z.string().trim().max(160),
});

type Coords = { lat: number; lng: number };

export function OrderProvider({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const [prefill, setPrefill] = useState<OrderPrefill>({});
  const openOrder = useCallback((p?: OrderPrefill) => {
    setPrefill(p ?? {});
    setOpen(true);
  }, []);
  const value = useMemo(() => ({ openOrder }), [openOrder]);

  return (
    <Ctx.Provider value={value}>
      {children}
      <OrderDialogContent open={open} setOpen={setOpen} prefill={prefill} />
    </Ctx.Provider>
  );
}

function OrderDialogContent({
  open,
  setOpen,
  prefill,
}: {
  open: boolean;
  setOpen: (v: boolean) => void;
  prefill: OrderPrefill;
}) {
  const lastOrder = useLastOrder();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [branch, setBranch] = useState("");
  const [items, setItems] = useState("");
  const [address, setAddress] = useState("");
  const [floor, setFloor] = useState("");
  const [apartment, setApartment] = useState("");
  const [landmark, setLandmark] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [photoBusy, setPhotoBusy] = useState(false);
  const [sending, setSending] = useState(false);

  const pickFile = async (picked: File | null | undefined) => {
    if (!picked) return;
    setPhotoBusy(true);
    try {
      setFile(await compressPrescription(picked));
    } finally {
      setPhotoBusy(false);
    }
  };
  const cameraRef = useRef<HTMLInputElement>(null);
  const galleryRef = useRef<HTMLInputElement>(null);
  const photoBoxRef = useRef<HTMLDivElement>(null);

  const [location, setLocation] = useState<Coords | null>(null);
  const [locStatus, setLocStatus] = useState<
    "idle" | "loading" | "success" | "error"
  >("idle");
  const [locMsg, setLocMsg] = useState("");

  const fillFrom = useCallback((o: SavedOrder) => {
    setName(o.name);
    setPhone(o.phone);
    setBranch(o.branch);
    setItems(o.items);
    setAddress(o.address);
    setFloor(o.floor);
    setApartment(o.apartment);
    setLandmark(o.landmark);
  }, []);

  // تجهيز الفورم عند الفتح
  useEffect(() => {
    if (!open) return;
    if (prefill.restoreLast && lastOrder) fillFrom(lastOrder);
    else if (lastOrder) {
      setName((v) => v || lastOrder.name);
      setPhone((v) => v || lastOrder.phone);
      setAddress((v) => v || lastOrder.address);
      setFloor((v) => v || lastOrder.floor);
      setApartment((v) => v || lastOrder.apartment);
      setLandmark((v) => v || lastOrder.landmark);
    }
    if (prefill.branch) setBranch(prefill.branch);
    if (prefill.items) setItems(prefill.items);
    if (prefill.addItem) {
      setItems((v) =>
        v.includes(prefill.addItem!) ? v : v ? `${v}\n${prefill.addItem}` : prefill.addItem!,
      );
    }
    if (locStatus === "idle") void fetchLocation();
    if (prefill.photo) {
      setTimeout(() => {
        photoBoxRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
        cameraRef.current?.click();
      }, 350);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, prefill]);

  useEffect(() => {
    if (!file) {
      setPreview(null);
      return;
    }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const fetchLocation = (): Promise<Coords | null> => {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      setLocStatus("error");
      setLocMsg("المتصفح مش بيسمح بتحديد الموقع هنا.");
      return Promise.resolve(null);
    }
    setLocStatus("loading");
    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const coords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
          setLocation(coords);
          setLocStatus("success");
          setLocMsg("");
          resolve(coords);
        },
        (err) => {
          setLocStatus("error");
          setLocMsg(
            err.code === err.PERMISSION_DENIED
              ? "الموقع مرفوض. اسمح بالوصول للموقع من إعدادات المتصفح — العنوان المكتوب يكفي برضه."
              : "مقدرناش نحدد الموقع. اضغط تاني أو كمّل بالعنوان المكتوب.",
          );
          resolve(null);
        },
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 },
      );
    });
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = orderSchema.safeParse({
      name,
      phone,
      branch,
      items,
      address,
      floor,
      apartment,
      landmark,
    });
    if (!parsed.success) {
      const next: Record<string, string> = {};
      for (const issue of parsed.error.issues) next[String(issue.path[0])] = issue.message;
      setErrors(next);
      return;
    }
    if (!parsed.data.items && !file) {
      setErrors({ items: "اكتب محتاج إيه أو ارفع صورة الروشتة" });
      return;
    }
    setErrors({});
    setSending(true);

    // نفتح تاب واتساب فورًا (من غير ما يمنعه المتصفح) ونحدد اللينك بعد التجهيز
    const win = window.open("", "_blank");

    try {
      const coords = location ?? (await fetchLocation());
      const d = parsed.data;
      // كل طلب يروح لواتساب الفرع المختار نفسه
      const target = branches.find((b) => b.name === d.branch) ?? bahrBranch;
      const waPhone = `2${target.whatsapp.replace(/\D/g, "")}`;

      let photoUrl: string | null = null;
      if (file) photoUrl = await uploadPrescription(file);

      let text =
        `السلام عليكم 👋\nالاسم: ${d.name}\nالموبايل: ${d.phone}\nالفرع: ${d.branch}` +
        `\nالطلب: ${d.items || "مرفق صورة روشتة"}` +
        `\nالعنوان: ${d.address}\nالدور: ${d.floor}\nرقم الشقة: ${d.apartment}`;
      if (d.landmark) text += `\nعلامة مميزة: ${d.landmark}`;
      if (coords) text += `\nموقعي: https://maps.google.com/?q=${coords.lat},${coords.lng}`;
      if (photoUrl) text += `\n📷 صورة الروشتة: ${photoUrl}`;
      else if (file) text += `\n📷 صورة الروشتة هبعتها في الشات.`;

      saveLastOrder({ ...d, createdAt: Date.now() });

      const url = `https://wa.me/${waPhone}?text=${encodeURIComponent(text)}`;
      if (win) win.location.href = url;
      else window.location.href = url;

      // لو الرفع فشل نحاول نشارك الصورة نفسها لو المتصفح بيسمح
      if (file && !photoUrl) {
        try {
          if (
            typeof navigator !== "undefined" &&
            typeof navigator.canShare === "function" &&
            navigator.canShare({ files: [file] })
          ) {
            await navigator.share({ files: [file], text });
          }
        } catch {
          /* المستخدم لغى المشاركة */
        }
      }
      setOpen(false);
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent
        dir="rtl"
        className="max-h-[90vh] overflow-y-auto text-right sm:max-w-md"
      >
        <DialogHeader className="text-right">
          <DialogTitle>تأكيد الطلب</DialogTitle>
          <DialogDescription>
            املأ البيانات وهنكمّل الطلب على واتساب فرع {site.nameAr}.
          </DialogDescription>
        </DialogHeader>

        {lastOrder && (
          <button
            type="button"
            onClick={() => fillFrom(lastOrder)}
            className="inline-flex w-full items-center justify-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-4 py-2.5 text-sm font-bold text-primary"
          >
            <RotateCcw className="size-4" />
            إعادة طلب آخر أوردر
          </button>
        )}

        <form onSubmit={submit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="order-name">الاسم</Label>
              <Input
                id="order-name"
                value={name}
                maxLength={80}
                onChange={(e) => setName(e.target.value)}
                placeholder="اكتب اسمك"
              />
              {errors["name"] && <p className="text-xs text-primary">{errors["name"]}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="order-phone">رقم الموبايل</Label>
              <Input
                id="order-phone"
                value={phone}
                inputMode="tel"
                maxLength={14}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="01xxxxxxxxx"
              />
              {errors["phone"] && (
                <p className="text-xs text-primary">{errors["phone"]}</p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="order-branch">الفرع</Label>
            <select
              id="order-branch"
              value={branch}
              onChange={(e) => setBranch(e.target.value)}
              className="h-11 w-full rounded-md border border-input bg-background px-3 text-sm"
            >
              <option value="">اختار الفرع</option>
              {branches.map((b) => (
                <option key={b.name} value={b.name}>
                  {b.name}
                </option>
              ))}
            </select>
            {errors["branch"] && (
              <p className="text-xs text-primary">{errors["branch"]}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="order-items">محتاج إيه؟</Label>
            <Textarea
              id="order-items"
              value={items}
              maxLength={800}
              rows={3}
              onChange={(e) => setItems(e.target.value)}
              placeholder="اكتب الأدوية أو المنتجات اللي محتاجها"
            />
            {errors["items"] && <p className="text-xs text-primary">{errors["items"]}</p>}
          </div>

          {/* صورة الروشتة */}
          <div ref={photoBoxRef} className="space-y-2 rounded-2xl border border-border bg-surface p-3">
            <Label>صورة الروشتة (اختياري)</Label>
            <input
              ref={cameraRef}
              type="file"
              accept="image/*"
              capture="environment"
              className="hidden"
              onChange={(e) => void pickFile(e.target.files?.[0])}
            />
            <input
              ref={galleryRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => void pickFile(e.target.files?.[0])}
            />
            {preview ? (
              <div className="space-y-2">
                <img
                  src={preview}
                  alt="معاينة صورة الروشتة"
                  className="max-h-56 w-full rounded-xl object-contain ring-1 ring-border"
                />
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => galleryRef.current?.click()}
                    className="inline-flex flex-1 items-center justify-center gap-2 rounded-full border border-border px-3 py-2 text-xs font-bold"
                  >
                    <ImagePlus className="size-4 text-primary" />
                    استبدال الصورة
                  </button>
                  <button
                    type="button"
                    onClick={() => setFile(null)}
                    className="inline-flex flex-1 items-center justify-center gap-2 rounded-full border border-border px-3 py-2 text-xs font-bold"
                  >
                    <Trash2 className="size-4 text-primary" />
                    حذف الصورة
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => cameraRef.current?.click()}
                  className="inline-flex flex-1 items-center justify-center gap-2 rounded-full border border-border px-3 py-2.5 text-xs font-bold"
                >
                  <Camera className="size-4 text-primary" />
                  صوّر الروشتة
                </button>
                <button
                  type="button"
                  onClick={() => galleryRef.current?.click()}
                  className="inline-flex flex-1 items-center justify-center gap-2 rounded-full border border-border px-3 py-2.5 text-xs font-bold"
                >
                  <ImagePlus className="size-4 text-primary" />
                  اختار من الصور
                </button>
              </div>
            )}
          </div>

          {/* بيانات التوصيل */}
          <div className="space-y-2">
            <Label htmlFor="order-address">العنوان</Label>
            <Input
              id="order-address"
              value={address}
              maxLength={200}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="اكتب عنوانك بالتفصيل"
            />
            {errors["address"] && (
              <p className="text-xs text-primary">{errors["address"]}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="order-floor">الدور</Label>
              <Input
                id="order-floor"
                value={floor}
                maxLength={30}
                onChange={(e) => setFloor(e.target.value)}
                placeholder="مثال: الدور الثالث"
              />
              {errors["floor"] && (
                <p className="text-xs text-primary">{errors["floor"]}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="order-apartment">رقم الشقة</Label>
              <Input
                id="order-apartment"
                value={apartment}
                maxLength={30}
                onChange={(e) => setApartment(e.target.value)}
                placeholder="مثال: 12"
              />
              {errors["apartment"] && (
                <p className="text-xs text-primary">{errors["apartment"]}</p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="order-landmark">
              علامة مميزة{" "}
              <span className="text-xs font-normal text-muted-foreground">اختياري</span>
            </Label>
            <Input
              id="order-landmark"
              value={landmark}
              maxLength={160}
              onChange={(e) => setLandmark(e.target.value)}
              placeholder="علامة مميزة (اختياري) — مثال: بجوار مسجد / أمام محل / بجوار صيدلية"
            />
          </div>

          <div className="space-y-2">
            <Label>الموقع (بيتبعت تلقائي مع الطلب)</Label>
            <button
              type="button"
              onClick={fetchLocation}
              disabled={locStatus === "loading"}
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-border bg-surface px-4 py-2.5 text-sm font-semibold transition-colors hover:border-primary/60 disabled:opacity-60"
            >
              {locStatus === "loading" ? (
                <>
                  <Navigation className="size-4 animate-pulse" />
                  جاري تحديد الموقع...
                </>
              ) : locStatus === "success" && location ? (
                <>
                  <MapPin className="size-4 text-primary" />
                  تم تحديد الموقع — هيتبعت مع الطلب
                </>
              ) : (
                <>
                  <MapPin className="size-4 text-primary" />
                  {locStatus === "error" ? "اعمل تحديد موقع تاني" : "ابعت موقعي"}
                </>
              )}
            </button>
            {locStatus === "error" && (
              <p className="text-xs text-muted-foreground">{locMsg}</p>
            )}
          </div>

          <button
            type="submit"
            disabled={sending || photoBusy}
            className="btn-red inline-flex w-full items-center justify-center gap-2 rounded-full px-6 py-3 font-bold"
          >
            <MessageCircle className="size-5" />
            {sending ? "جاري تجهيز الطلب..." : "تأكيد الطلب"}
          </button>
          <p className="text-center text-[0.7rem] text-muted-foreground">
            الطلب مش بيتبعت غير لما تدوس «تأكيد الطلب».
          </p>
        </form>
      </DialogContent>
    </Dialog>
  );
}

/** زر يفتح فورم الطلب (بنفس واجهة الاستخدام القديمة) */
export function OrderDialog({
  className,
  children,
  defaultBranch,
}: {
  className?: string;
  children: React.ReactNode;
  defaultBranch?: string;
}) {
  const { openOrder } = useOrder();
  return (
    <button
      type="button"
      className={className}
      onClick={() => openOrder(defaultBranch ? { branch: defaultBranch } : {})}
    >
      {children}
    </button>
  );
}

export { X as _X };
