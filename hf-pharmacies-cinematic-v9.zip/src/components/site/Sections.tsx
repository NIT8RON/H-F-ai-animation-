import { useEffect, useRef } from "react";
import {
  ArrowLeft,
  Clock,
  Facebook,
  HeartPulse,
  Instagram,
  MapPin,
  MessageCircle,
  Navigation,
  Phone,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Star,
  Stethoscope,
  Truck,
  Wallet,
} from "lucide-react";
import heroBg from "@/assets/hero-bg.jpg";
import aboutImage from "@/assets/about.jpg";
import { OrderDialog } from "./OrderDialog";
import { QuickActions } from "./QuickActions";
import { CinematicBackground } from "./CinematicBackground";
import { isOpenNow } from "@/lib/hours";
import { useNow } from "@/lib/use-now";
import {
  aboutPoints,
  branches,
  features,
  services,
  site,
  trustBar,
  waLink,
} from "@/data/site";

const logo = "/hf-logo.jpeg";

const icons = {
  truck: Truck,
  shield: ShieldCheck,
  clock: Clock,
  heart: HeartPulse,
  phone: Phone,
};

function Reveal({ children, className = "", delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  return <div className={`reveal ${className}`} style={{ "--delay": `${delay}ms` } as React.CSSProperties}>{children}</div>;
}

function SectionHead({ eyebrow, title, sub }: { eyebrow: string; title: string; sub?: string }) {
  return (
    <Reveal className="mx-auto mb-14 max-w-3xl text-center">
      <span className="eyebrow"><Sparkles className="size-3" /> {eyebrow}</span>
      <h2 className="mt-4 text-4xl font-black tracking-tight sm:text-5xl">{title}</h2>
      {sub && <p className="mx-auto mt-4 max-w-2xl text-base leading-8 text-muted-foreground">{sub}</p>}
    </Reveal>
  );
}

export function Hero() {
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const root = ref.current;
    if (!root || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const onMove = (e: PointerEvent) => {
      if (e.pointerType === "touch") return;
      const r = root.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      root.style.setProperty("--hero-x", `${x * 22}px`);
      root.style.setProperty("--hero-y", `${y * 16}px`);
      root.style.setProperty("--hero-rx", `${-y * 2.2}deg`);
      root.style.setProperty("--hero-ry", `${x * 2.8}deg`);
    };
    root.addEventListener("pointermove", onMove, { passive: true });
    return () => root.removeEventListener("pointermove", onMove);
  }, []);

  return (
    <section ref={ref} id="home" className="hero-scene-v2 relative overflow-hidden">
      <img src={heroBg} alt="" aria-hidden className="hero-media-v2" fetchPriority="high" decoding="async" />
      <div className="hero-shade-v2" aria-hidden />
      <div className="hero-noise-v2" aria-hidden />
      <div className="hero-grid-v2" aria-hidden />
      <div className="hero-redline-v2" aria-hidden />
      <div className="hero-medical-mark hero-medical-mark-a" aria-hidden>+</div>
      <div className="hero-medical-mark hero-medical-mark-b" aria-hidden>+</div>

      <div className="relative z-10 mx-auto flex min-h-[820px] max-w-[1440px] items-end px-5 pb-20 pt-36 sm:px-8 lg:min-h-[900px] lg:pb-24">
        <div className="hero-v2-copy max-w-3xl lg:mr-auto lg:max-w-[700px]">
          <Reveal delay={50}>
            <div className="hero-v2-eyebrow"><span>H&amp;F PHARMACIES</span><i /> <b>منذ 1999</b></div>
          </Reveal>
          <Reveal delay={120}>
            <h1 className="hero-v2-title">
              صحتك،<br />
              <span>في أيدٍ أمينة.</span>
            </h1>
          </Reveal>
          <Reveal delay={210}>
            <p className="hero-v2-lead">صيدليات هشام و فؤاد — خدمة صيدلية موثوقة، طلب أسهل، وتوصيل لحد بابك.</p>
          </Reveal>
          <Reveal delay={290} className="hero-v2-actions">
            <OrderDialog className="hero-primary-cta magnetic"><ShoppingBag className="size-5" /> اطلب أوردر <ArrowLeft className="size-4" /></OrderDialog>
            <a href={`tel:${site.phone}`} className="hero-secondary-cta magnetic"><Phone className="size-5" /> اتصل بنا</a>
          </Reveal>
          <Reveal delay={370}>
            <div className="hero-v2-proof">
              <div><strong>7</strong><span>فروع في طنطا</span></div>
              <div><strong>24/7</strong><span>فروع متاحة</span></div>
              <div><strong>01</strong><span>طلبك يبدأ هنا</span></div>
            </div>
          </Reveal>
        </div>

        <div className="hero-v2-visual" aria-hidden="true">
          <div className="hero-v2-orbit orbit-1" />
          <div className="hero-v2-orbit orbit-2" />
          <div className="hero-v2-panel" style={{ transform: "translate3d(calc(var(--hero-x, 0px) + var(--hero-scroll-x, 0px)), calc(var(--hero-y, 0px) + var(--hero-scroll-y, 0px)), 0) rotateX(var(--hero-rx, 0deg)) rotateY(var(--hero-ry, 0deg)) scale(var(--hero-panel-scale, 1))" }}>
            <div className="hero-panel-top"><span>H&amp;F</span><span>PHARMACIES</span></div>
            <img src={logo} alt="" />
            <div className="hero-panel-bottom"><span>HEALTH</span><i /> <span>CARE</span><i /> <span>TRUST</span></div>
          </div>
          <div className="hero-v2-float float-one"><Truck/><span>توصيل سريع</span></div>
          <div className="hero-v2-float float-two"><ShieldCheck/><span>أدوية موثوقة</span></div>
        </div>
      </div>

      <div className="hero-v2-bottom">
        <span>SCROLL TO EXPLORE</span><i />
      </div>
    </section>
  );
}

export function Services() {
  return (
    <section id="services" className="cinematic-section py-24">
      <CinematicBackground scene="services" />
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHead eyebrow="خدماتنا" title="كل اللي تحتاجه… في مكان واحد" sub="خدمات صيدلية مصممة عشان تختصر عليك الوقت وتخلي طلبك أسهل." />
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {services.map((s, i) => {
            const Icon = icons[s.icon];
            return <Reveal key={s.title} delay={i * 70} className="tilt-card service-card">
              <span className="service-icon"><Icon/></span>
              <h3>{s.title}</h3><p>{s.desc}</p>
              <span className="card-arrow"><ArrowLeft/></span>
            </Reveal>;
          })}
        </div>
      </div>
    </section>
  );
}

export function SocialHub({ className = "py-10" }: { className?: string }) {
  return <section className={`${className} cinematic-social-section`}><CinematicBackground scene="social" /><div className="mx-auto max-w-4xl px-5 sm:px-8"><Reveal className="social-hub">
    <div className="social-copy"><span className="eyebrow">ابقى على تواصل</span><h2>كل طرق التواصل معانا</h2><p>اطلب، اسأل، تابعنا أو ادفع — كل حاجة في مكان واحد.</p></div>
    <div className="social-links">
      <a href={site.whatsapp} target="_blank" rel="noreferrer"><MessageCircle/> واتساب</a>
      <a href={site.instagram} target="_blank" rel="noreferrer"><Instagram/> Instagram</a>
      <a href={site.facebook} target="_blank" rel="noreferrer"><Facebook/> Facebook</a>
      <a href={site.instapay} target="_blank" rel="noreferrer"><Wallet/> InstaPay</a>
    </div>
  </Reveal></div></section>;
}

export function Branches() {
  const now = useNow();
  return <section id="branches" className="cinematic-section py-24">
    <CinematicBackground scene="branches" />
    <div className="mx-auto max-w-7xl px-5 sm:px-8">
      <SectionHead eyebrow="فروعنا" title="قريبين منك" sub="سبعة فروع في طنطا، مع طرق مباشرة للاتصال والواتساب والموقع." />
      <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {branches.map((b, i) => <Reveal key={b.name} delay={i * 45} className="tilt-card branch-card">
          <div className="branch-top"><span>{b.hours}</span><b>{isOpenNow(b.schedule, now) ? '● مفتوح الآن' : '● مغلق الآن'}</b></div>
          <h3>{b.name}</h3><p className="branch-address">{b.address ?? 'طنطا'}</p>
          <div className="branch-actions">
            <a href={`tel:${b.whatsapp}`}><Phone/> اتصال</a>
            <a href={waLink(b.whatsapp)} target="_blank" rel="noreferrer"><MessageCircle/> واتساب</a>
            <a href={b.map} target="_blank" rel="noreferrer"><Navigation/> الموقع</a>
          </div>
          <OrderDialog defaultBranch={b.name} className="btn-red mt-3 inline-flex w-full items-center justify-center gap-2 rounded-full px-4 py-3 text-sm font-bold"><MessageCircle className="size-4"/> اطلب من الفرع</OrderDialog>
        </Reveal>)}
      </div>
      <Reveal className="trust-strip mt-12">{trustBar.map(t => <div key={t.title}><strong>{t.title}</strong><span>{t.sub}</span></div>)}</Reveal>
    </div>
  </section>;
}

export function About() {
  return <section id="about" className="about-stage py-28">
    <CinematicBackground scene="about" />
    <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 sm:px-8 lg:grid-cols-2">
      <Reveal className="about-visual"><img src={aboutImage} alt="داخل إحدى صيدليات هشام و فؤاد" loading="lazy" decoding="async"/><div className="about-overlay"/><div className="about-badge"><Star/><b>من 1999</b><span>ثقة بتكبر كل يوم</span></div></Reveal>
      <Reveal className="about-copy"><span className="eyebrow">من نحن</span><h2>صيدلية قريبة منك،<br/><span>وتجربة أريح ليك.</span></h2><p>هدفنا بسيط: الدواء يوصلك بسرعة وإنت مطمّن إنه أصلي. بنوفر احتياجاتك الطبية ومنتجات العناية، مع فريق مستعد يساعدك في أي وقت.</p><ul>{aboutPoints.map(p => <li key={p}><ShieldCheck/> {p}</li>)}</ul><OrderDialog className="btn-red mt-7 inline-flex items-center gap-2 rounded-full px-7 py-3.5 font-bold"><MessageCircle/> ابدأ طلبك</OrderDialog></Reveal>
    </div>
  </section>;
}

export function Contact() {
  const cards = [
    { title:'الهاتف', value:site.phone, href:`tel:${site.phone}`, Icon:Phone, cta:'اتصل الآن' },
    { title:'واتساب', value:'اطلب واستفسر بسهولة', href:site.whatsapp, Icon:MessageCircle, cta:'راسلنا' },
    { title:'InstaPay', value:'ادفع بسهولة وأمان', href:site.instapay, Icon:Wallet, cta:'ادفع الآن' },
    { title:'Instagram', value:'@hishamandfouad.ph', href:site.instagram, Icon:Instagram, cta:'تابعنا' },
    { title:'Facebook', value:'Hesham & Fouad Pharmacies', href:site.facebook, Icon:Facebook, cta:'زور الصفحة' },
  ];
  return <section id="contact" className="cinematic-contact py-24"><CinematicBackground scene="contact" /><div className="mx-auto max-w-7xl px-5 sm:px-8"><SectionHead eyebrow="تواصل معنا" title="إحنا جاهزين" sub="اختار الطريقة الأسهل ليك وابدأ التواصل فورًا."/><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">{cards.map(({title,value,href,Icon,cta},i)=><Reveal key={title} delay={i*50} className="contact-card"><Icon/><h3>{title}</h3><p>{value}</p><a href={href} target={href.startsWith('tel:')?undefined:'_blank'} rel="noreferrer">{cta}<ArrowLeft/></a></Reveal>)}</div><Reveal className="final-cta mt-14"><div><span className="eyebrow">جاهز تطلب؟</span><h2>خلّي طلبك علينا.</h2><p>اختار الفرع الأقرب ليك وابدأ طلبك على واتساب بسهولة.</p></div><OrderDialog className="magnetic btn-red inline-flex items-center gap-2 rounded-full px-8 py-4 font-extrabold"><ShoppingBag/> اطلب أوردر</OrderDialog></Reveal></div></section>;
}

export function Footer() {
  return <footer className="site-footer"><div className="mx-auto flex max-w-7xl flex-col items-center gap-3 px-5 py-10 text-center"><img src={logo} alt="شعار صيدليات هشام و فؤاد"/><p className="font-bold">{site.nameAr}</p><p className="text-xs text-muted-foreground">© {new Date().getFullYear()} H&amp;F Pharmacies — طنطا</p><a href={site.madeBy} target="_blank" rel="noreferrer" className="text-xs text-muted-foreground hover:text-primary">Made by LAMSA.EA</a></div></footer>;
}
