import { useEffect, useState } from "react";

/** الوقت الحالي، بيتحدّث كل دقيقة (للحالة مفتوح/مغلق) */
export function useNow(intervalMs = 60_000): Date {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
  return now;
}
