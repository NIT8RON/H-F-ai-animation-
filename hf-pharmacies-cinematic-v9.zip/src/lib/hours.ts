import type { Branch, Schedule } from "@/data/site";

/** الوقت الحالي بتوقيت القاهرة كساعات عشرية (مثال 13.5 = 1:30 م) */
export function cairoHourNow(now: Date = new Date()): number {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Africa/Cairo",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(now);
  const [h, m] = parts.split(":").map(Number);
  return (h ?? 0) + (m ?? 0) / 60;
}

export function isOpenNow(schedule: Schedule, now: Date = new Date()): boolean {
  if (schedule.kind === "24h") return true;
  const h = cairoHourNow(now);
  const { fromHour, toHour } = schedule;
  // النهاية بعد منتصف الليل (٢ ص) تُحسب في اليوم التالي
  if (toHour <= fromHour) return h >= fromHour || h < toHour;
  return h >= fromHour && h < toHour;
}

const R = 6371; // km

export function distanceKm(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
): number {
  const toRad = (v: number) => (v * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

export function formatDistance(km: number): string {
  return km < 1 ? `${Math.round(km * 1000)} متر` : `${km.toFixed(1)} كم`;
}

export function rankBranches(
  coords: { lat: number; lng: number },
  list: Branch[],
): { branch: Branch; km: number }[] {
  return list
    .map((branch) => ({ branch, km: distanceKm(coords, branch) }))
    .sort((a, b) => a.km - b.km);
}
