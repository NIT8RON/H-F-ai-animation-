import { useCallback, useEffect, useState } from "react";

const FAV_KEY = "hf_favorites_v1";
const LAST_ORDER_KEY = "hf_last_order_v1";

export type SavedOrder = {
  name: string;
  phone: string;
  branch: string;
  items: string;
  address: string;
  floor: string;
  apartment: string;
  landmark: string;
  createdAt: number;
};

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* ignore */
  }
  window.dispatchEvent(new Event("hf-store"));
}

export function saveLastOrder(order: SavedOrder) {
  write(LAST_ORDER_KEY, order);
}

export function useLastOrder() {
  const [order, setOrder] = useState<SavedOrder | null>(null);
  useEffect(() => {
    const sync = () => setOrder(read<SavedOrder | null>(LAST_ORDER_KEY, null));
    sync();
    window.addEventListener("hf-store", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("hf-store", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);
  return order;
}

export function useFavorites() {
  const [favorites, setFavorites] = useState<string[]>([]);

  useEffect(() => {
    const sync = () => setFavorites(read<string[]>(FAV_KEY, []));
    sync();
    window.addEventListener("hf-store", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("hf-store", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  const toggle = useCallback((item: string) => {
    const current = read<string[]>(FAV_KEY, []);
    const next = current.includes(item)
      ? current.filter((i) => i !== item)
      : [...current, item];
    write(FAV_KEY, next);
  }, []);

  const clear = useCallback(() => write(FAV_KEY, []), []);

  return { favorites, toggle, clear };
}
