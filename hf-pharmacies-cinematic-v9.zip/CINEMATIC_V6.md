# H&F Pharmacies — Cinematic V6

This version adds a dependency-free cinematic interaction layer on top of the existing V4 experience.

## Added
- Scroll-driven hero depth and parallax.
- Persistent cinematic scroll progress indicator.
- Cursor spotlight/ambient lighting on desktop.
- More dimensional glass panel and logo treatment.
- Floating-card light sweeps.
- Section divider reveal choreography.
- Enhanced service/branch/contact card hover depth and spotlight.
- Trust-strip sweep and CTA ambient glow.
- Image sweep treatment in the About section.
- Stronger reveal animation with blur-to-sharp entrance.
- Mobile and `prefers-reduced-motion` safeguards.

## Important
- Supabase remains unchanged.
- No new runtime dependency was added.
- Existing components and site content were preserved.
- Build verification could not be completed in this environment because dependencies are not installed and the npm registry is unavailable.


## V6 finishing pass
- Delegated/dynamic tilt and magnetic bindings for late-rendered React UI.
- Scroll-driven hero depth, grid drift, panel scale and copy movement.
- Pointer-following card light sweeps and stronger depth treatment.
- Enhanced social, CTA, about and footer micro-interactions.
- Coarse-pointer and reduced-motion safeguards.
